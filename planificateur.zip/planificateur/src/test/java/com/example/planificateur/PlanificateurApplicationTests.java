package com.example.planificateur;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlanificateurApplicationTests {

	@Test
	void contextLoads() {
	}

}
